public class Arreglos {
	public static void main (String args[]){
	int nombre_variable[] = new int [5];
	nombre_variable[0] = 1;
	nombre_variable[1] = 2;
	nombre_variable[2] = 3;
	nombre_variable[3] = 4;
	nombre_variable[4] = 5;

	for (int i=0; i<5; i++)
	{
		System.out.println(nombre_variable[i]);
	}
}
}