public class Ahorros {
	public static void main(String args[]){
		int ahorro = 500, i;
		
		System.out.println("========= AHORROS ACUMULADOS ==========");
		for (i=1; i <=12; i++)
		{
			System.out.println("Mes " + i);
			System.out.println("Tienes un ahorro de: $" + ahorro);
			ahorro = ahorro + 500;
			if ( i > 1)
			{
				System.out.println("Tienes un interés del 9%");
				interes = ahorro * .09
				ahorrot = ahorro + interés
				System.out.println("El ahorro total del mes es de: $" + ahorrot);
			}
		}
	}
}