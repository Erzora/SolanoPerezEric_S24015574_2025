public class NombresWhile{
	public static void main (String args[]) {
		int i = 0;
		String nombre [] = {"Eric", "Abraham", "Laura", "Uzziel", "Juan", "Andres", "Fabiola", "Ricardo", "Bandala", "Jeffrey"};

		while (i <= 9)
		{
			System.out.println(nombre[i]);
			i++;
		}
	}
}