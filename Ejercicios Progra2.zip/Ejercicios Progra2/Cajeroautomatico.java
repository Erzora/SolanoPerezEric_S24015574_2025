import java.util.Scanner;
public class Cajeroautomatico{
	public static void main (String args[]){
		int saldod = 5000, retiro = 0, saldoa;
		boolean continuar = true; 
		Scanner sc = new Scanner(System.in);
		
		do
		{
			System.out.println("========== CAJERO AUTOMÁTICO ==========");
			System.out.print("Solicita la cantidad que deseas retirar: $");	
			retiro = sc.nextInt();

			if (retiro > saldod)
			{
				System.out.println("Saldo insuficiente");
			}
			else
			{
				saldoa = saldod - retiro;
				System.out.println("Retiro Exitoso");
				System.out.println("Saldo actual: $" + saldoa);
			}
			
			System.out.println("¿Deseas Continuar?");
			System.out.println("true. Sí");
			System.out.println("false. No");
			continuar = sc.nextBoolean();
			if (continuar == false)
			{
				System.out.println("Vuelva Pronto");
			}
			
		}
		while (continuar);
		sc.close();
	}
}