import java.util.Scanner;

public class CalificacionesPromedio {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		double[] calificaciones = new double[6];
		double suma = 0;

	for (int i = 0; i < calificaciones.length; i++) {
		System.out.print("Ingrese la calificación del estudiante " + (i + 1) + ": ");
		calificaciones[i] = sc.nextDouble();

		if (calificaciones[i] < 1 || calificaciones[i] > 10) {
			System.out.println("Calificación inválida. Debe estar entre 1 y 10.");
			i--;
			continue;
		}

		suma += calificaciones[i];
	}

		double promedio = suma / calificaciones.length;

		System.out.println("\n--- Reporte del grupo ---");
		System.out.println("Calificaciones capturadas:");
		for (int i = 0; i < calificaciones.length; i++) {
			System.out.println("Estudiante " + (i + 1) + ": " + calificaciones[i]);
		}
			System.out.printf("Promedio general del grupo: %.2f%n", promedio);

		sc.close();
	}
}