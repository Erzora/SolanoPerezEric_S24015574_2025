import java.util.Scanner;

public class Academia {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int[][] alumnos = new int[3][4];

	System.out.println("Ingrese los datos de 12 estudiantes:");
	System.out.println("Niveles: 0 = Básico, 1 = Medio, 2 = Perfeccionamiento");
	System.out.println("Idiomas: 0 = Inglés, 1 = Francés, 2 = Alemán, 3 = Ruso\n");

		for (int i = 1; i <= 12; i++) {
			System.out.println("Estudiante " + i + ":");

		System.out.print("Ingrese nivel (0-2): ");
		int nivel = sc.nextInt();
		while (nivel < 0 || nivel > 2) {
		System.out.print("Nivel inválido. Ingrese nuevamente (0-2): ");
		nivel = sc.nextInt();
		}

		System.out.print("Ingrese idioma (0-3): ");
		int idioma = sc.nextInt();
		while (idioma < 0 || idioma > 3) {
		System.out.print("Idioma inválido. Ingrese nuevamente (0-3): ");
		idioma = sc.nextInt();
		}

		alumnos[nivel][idioma]++;
		}

		System.out.println("\n--- Distribución de estudiantes ---");
		String[] niveles = {"Básico", "Medio", "Perfeccionamiento"};
		String[] idiomas = {"Inglés", "Francés", "Alemán", "Ruso"};

		for (int i = 0; i < alumnos.length; i++) {
			for (int j = 0; j < alumnos[i].length; j++) {
			System.out.println("Nivel " + niveles[i] + " - " + idiomas[j] + ": " + alumnos[i][j] + " estudiantes");
			}
		}

		sc.close();
	}
}