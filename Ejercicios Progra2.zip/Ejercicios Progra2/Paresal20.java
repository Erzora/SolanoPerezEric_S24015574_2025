public class Paresal20 {
	public static void main (String args[]) {
		int numero = 2;

		while (numero <= 20)
		{
			System.out.println(numero);
			numero = numero + 2;
		}
	}
}