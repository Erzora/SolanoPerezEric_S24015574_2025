import java.util.Scanner;

public class Atletas {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int n = 5;

		String[][] atletas = new String[n][4];

		for (int i = 0; i < n; i++) {
			System.out.println("\nIngrese los datos del atleta " + (i + 1) + ":");

			System.out.print("Nombre: ");
			atletas[i][0] = sc.nextLine();

			System.out.print("Apellido: ");
			atletas[i][1] = sc.nextLine();

			System.out.print("Especialidad (100 m, 200 m, etc.): ");
			atletas[i][2] = sc.nextLine();

			System.out.print("Tiempo registrado (segundos): ");
			atletas[i][3] = sc.nextLine();
		}

		double mejorTiempo = Double.parseDouble(atletas[0][3]);
		int indiceMejor = 0;

		for (int i = 1; i < n; i++) {
			double tiempo = Double.parseDouble(atletas[i][3]);
			if (tiempo < mejorTiempo) {
			mejorTiempo = tiempo;
			indiceMejor = i;
		}
	}

		System.out.println("\n--- Resultados de Atletas ---");
		System.out.printf("%-10s %-10s %-15s %-10s%n", "Nombre", "Apellido", "Especialidad", "Tiempo (s)");
		for (int i = 0; i < n; i++) {
			String marca = (i == indiceMejor) ? " <-- Mejor tiempo" : "";
			System.out.printf("%-10s %-10s %-15s %-10s%s%n",
			atletas[i][0], atletas[i][1], atletas[i][2], atletas[i][3], marca);
		}

		System.out.println("\nEl atleta con el mejor tiempo es: "
			+ atletas[indiceMejor][0] + " " + atletas[indiceMejor][1]
			+ " (" + atletas[indiceMejor][2] + ") con " + mejorTiempo + " segundos.");

		sc.close();
	}
}