import java.util.Scanner;

public class BuscarNumero {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int[] numeros = new int[8];

	System.out.println("Ingrese 8 números:");
		for (int i = 0; i < numeros.length; i++) {
			System.out.print("Número " + (i + 1) + ": ");
			numeros[i] = sc.nextInt();
		}

		System.out.print("\nIngrese el número que desea buscar: ");
			int buscado = sc.nextInt();

		boolean encontrado = false;
		for (int i = 0; i < numeros.length; i++) {
			if (numeros[i] == buscado) {
			encontrado = true;
			break;
		}
	}

		if (encontrado) {
			System.out.println("El número " + buscado + " SÍ existe en el arreglo.");
		} else {
			System.out.println("El número " + buscado + " NO existe en el arreglo.");
	}

	sc.close();
	}
}