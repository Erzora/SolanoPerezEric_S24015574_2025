import java.util.Scanner;

public class Inverso {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int[] numeros = new int[10];

	System.out.println("Ingrese 10 números:");
		for (int i = 0; i < numeros.length; i++) {
		System.out.print("Número " + (i + 1) + ": ");
		numeros[i] = sc.nextInt();
	}

	System.out.println("\nNúmeros en orden inverso:");
		for (int i = numeros.length - 1; i >= 0; i--) {
			System.out.println(numeros[i]);
	}

	sc.close();
	}
}