import java.util.Scanner;

public class Temperaturas {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		String[] paises = new String[4];

		double[][] temperaturas = new double[4][3];

		double[] medias = new double[4];

		for (int i = 0; i < paises.length; i++) {
			System.out.print("Ingrese el nombre del país " + (i + 1) + ": ");
			paises[i] = sc.nextLine();

		System.out.println("Ingrese las 3 temperaturas medias mensuales de " + paises[i] + ":");
		double suma = 0;
		for (int j = 0; j < 3; j++) {
			System.out.print("Mes " + (j + 1) + ": ");
			temperaturas[i][j] = sc.nextDouble();
			suma += temperaturas[i][j];
		}
		sc.nextLine();
		medias[i] = suma / 3;
		}

		System.out.println("\n--- Temperaturas registradas ---");
			for (int i = 0; i < paises.length; i++) {
			System.out.print(paises[i] + ": ");
			for (int j = 0; j < 3; j++) {
			System.out.print(temperaturas[i][j] + " ");
			}
			System.out.println();
		}

		System.out.println("\n--- Temperatura media trimestral ---");
		double mayorMedia = medias[0];
		String paisMayor = paises[0];
			for (int i = 0; i < paises.length; i++) {
			System.out.println(paises[i] + " - Media: " + medias[i]);
				if (medias[i] > mayorMedia) {
				mayorMedia = medias[i];
				paisMayor = paises[i];
			}
		}

		System.out.println("\nEl país con la temperatura media trimestral más alta es: " 
			+ paisMayor + " (" + mayorMedia + ")");

		sc.close();
	}
}