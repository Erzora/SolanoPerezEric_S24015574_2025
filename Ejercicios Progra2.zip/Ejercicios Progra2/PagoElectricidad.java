import java.util.Scanner;
public class PagoElectricidad {
	public static void main (String args[]) {
		int adeudo = 1000, pagodelmes = 250;
		int opcion, pago, resultado, cambio;
		boolean continuar = true; 
		Scanner sc = new Scanner(System.in);
		
		do 
		{
			System.out.println("========== PAGO DE LA ELECTRICIDAD ==========");
			System.out.println("1. CONSULTA");
			System.out.println("2. PAGO DEL MES");
			System.out.println("3. PAGO ADEUDO");
			System.out.println("4. SALIR");
			System.out.print("\nEscoja una opcion para continuar con el procedimiento: ");
			opcion = sc.nextInt();

			switch (opcion)
			{
				case 1:
					System.out.println("===== CONSULTA =====");
					System.out.println("Adeudo: " + adeudo);
					System.out.println("Pago de este mes: $" + pagodelmes);
					System.out.println("¿Desea Continuar?");
					System.out.println("true. Sí");
					System.out.println("false. No");
					continuar = sc.nextBoolean();
					if (continuar == false)
					{
						System.out.println("Vuelva pronto");
					}
					break;
				case 2:
					System.out.println("===== PAGO DEL MES =====");
					System.out.println("Usted debe pagar en este mes: $" + pagodelmes);
					System.out.print("Ingresa la cantidad que pagara: ");
					pago = sc.nextInt();
					System.out.println("Pago efectuado: $" + pago);
					if (pago > pagodelmes)
					{
						cambio = pago - pagodelmes;
						System.out.println("Cambio: $" + cambio);
					}
					else
					{
						resultado = pagodelmes - pago;
						System.out.println("Usted todavía debe: $" + resultado);
					}
					System.out.println("Gracias por su pago");
					System.out.println("¿Desea Continuar?");
					System.out.println("true. Sí");
					System.out.println("false. No");
					continuar = sc.nextBoolean();
					if (continuar == false)
					{
						System.out.println("Vuelva pronto");
					}
					break;
				case 3:
					System.out.println("===== ADEUDO =====");
					System.out.println("Usted tiene un adeudo de: $" + adeudo);
					System.out.print("Ingresa la cantidad que pagara: ");
					pago = sc.nextInt();
					if (pago > adeudo)
					{
						cambio = pago - adeudo;
						System.out.println("Cambio: $" + cambio);
					}
					else
					{
						resultado = adeudo - pago;
						System.out.println("Usted todavía debe: $" + resultado);
					}
					System.out.println("¿Desea Continuar?");
					System.out.println("true. Sí");
					System.out.println("false. No");
					continuar = sc.nextBoolean();
					if (continuar == false)
					{
						System.out.println("Vuelva pronto");
					}
					break;
				case 4:
					System.out.println("Vuelva pronto");
					continuar = false;
					break;
				default:
					System.out.println("Opción no valida, escoge una opcion valida");
					break;
			}
		}
		while (continuar);
		sc.close();
	}
}