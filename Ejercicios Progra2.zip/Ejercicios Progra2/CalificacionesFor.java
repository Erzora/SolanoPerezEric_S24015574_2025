import java.util.Scanner;
public class CalificacionesFor{
	public static void main (String args[]){
		int i, calificacion, calificaciont = 0, aprobados = 0, reprobados = 0;
		double promedio;
		Scanner sc = new Scanner(System.in);

		for (i = 1; i <=5; i++)
		{
			System.out.println("Ingresa la calificación del alumno " + i);
			calificacion = sc.nextInt();
			if (calificacion < 6)
			{
				reprobados = reprobados + 1;	
			}
			else
			{
				aprobados = aprobados + 1;
				if (calificacion > 10)
				{
					System.out.println("Ingresa una cantidad valida");
					i = i - 1;
				}
			}
			
			calificaciont = calificaciont + calificacion;
			
		}

		promedio = calificaciont / 5;

		System.out.println("========== REPORTE DE CALIFICACIONES ==========");
		System.out.println("Alumnos reprobados: " + reprobados);
		System.out.println("Alumnos aprobados: " + aprobados);
		System.out.println("Promedio del grupo: " + promedio);
	}
}