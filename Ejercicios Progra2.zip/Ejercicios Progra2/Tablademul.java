import java.util.Scanner;
public class Tablademul {
	public static void main (String args[]){
		int i, numero, resultado;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ingresa el número que deseas saber su tabla");
		numero = sc.nextInt();

		for (i = 1; i <= 10; i++)
		{
			resultado = numero * i;
			System.out.println(numero + " x " + i + " = " + resultado);
		}
	}
}