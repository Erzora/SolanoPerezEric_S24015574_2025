import java.util.Scanner;

public class TiendaRopa {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		String[][] articulos = new String[3][3];

		articulos[0][0] = "Camisa";
		articulos[1][0] = "Zapato";
		articulos[2][0] = "Pantalón";

		for (int i = 0; i < articulos.length; i++) {
			System.out.println("\nArtículo: " + articulos[i][0]);

		System.out.print("Ingrese la talla: ");
		articulos[i][1] = sc.nextLine();

		System.out.print("Ingrese el color: ");
		articulos[i][2] = sc.nextLine();
		}

		System.out.println("\n--- Información de artículos ---");
		System.out.printf("%-12s %-10s %-10s%n", "Artículo", "Talla", "Color");
		for (int i = 0; i < articulos.length; i++) {
			System.out.printf("%-12s %-10s %-10s%n", articulos[i][0], articulos[i][1], articulos[i][2]);
		}

		sc.close();
	}
}