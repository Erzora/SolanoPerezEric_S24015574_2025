import java.util.Scanner;

public class VentasSemana {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

	double[] ventas = new double[7];
	double total = 0;

	for (int i = 0; i < ventas.length; i++) {
		System.out.print("Ingrese la venta del día " + (i + 1) + ": ");
		ventas[i] = sc.nextDouble();
		total += ventas[i];
	}

	double mayorVenta = ventas[0];
	int diaMayor = 0;
		for (int i = 1; i < ventas.length; i++) {
		if (ventas[i] > mayorVenta) {
		mayorVenta = ventas[i];
		diaMayor = i;
		}
	}

		System.out.println("\n--- Reporte de Ventas ---");
		System.out.println("Venta total de la semana: $" + total);
		System.out.println("El día con mayor venta fue el día " + (diaMayor + 1) + " con $" + mayorVenta);

	sc.close();
	}
}